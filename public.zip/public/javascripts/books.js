﻿// // $(".close").click(function() {
// //    if (confirm("确定删除吗？")) {
// //        var id = $(this).data("id");
// //        var row = $(this).parents(".booklist");
// //        $.ajax({
// //            url: "/book/" + id,
// //            method: "delete",
// //        }).done(function(data) {
// //            console.log(data);
// //            row.fadeOut();
// //        });
// //    }
// // });
 


// var uploader = new plupload.Uploader({
//     runtimes: 'html5,flash,silverlight,html4',
//     browse_button: "upload",
//     url: '/book',
//     flash_swf_url: '/plupload-2.1.8/js/Moxie.swf',
//     silverlight_xap_url: '/plupload-2.1.8/js/Moxie.xap',
//     filters: {
//         max_file_size: "3mb",
//         mime_types: [
//             { title: "Image files", extensions: "jpg,gif,png" },
//             { title: "Zip files", extensions: "zip" }
//         ]
//     },
//     init: {
//         PostInit: function () {
//             console.log('图片上传附件初始化完成')
//         },
//         FilesAdded: function (up, files) {
//             plupload.each(files, function (file) {
//                 uploader.start();
//             });
//         },
//         UploadProgress: function (up, file) {
//         },
//         Error: function (up, err) {
//         }
//     }
// });
// uploader.init();
// uploader.disableBrowse(false);
// uploader.bind('FileUploaded', function (upldr, file, object) {
//      console.log('图片上传事件')
//     var data = JSON.parse(object.response);
//     console.log('使用插件上传图片数据为'+data);
//     $("#img").attr("src", data);
//     $("#imgvalue").val(data);
//     console.log($("#imgvalue").val());
// });